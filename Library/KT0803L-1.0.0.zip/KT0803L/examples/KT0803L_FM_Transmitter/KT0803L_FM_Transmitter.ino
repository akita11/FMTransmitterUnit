/*
 * KT0803L FM transmitter sample for Arduino UNO R3
 *
 * KT0803L is a 3.3V device (IOVDD 1.6 ~ 3.6V) and UNO R3 is a 5V board.
 *   - Power KT0803L from the UNO 3.3V pin.
 *   - The internal pull-ups of ATmega328P (to 5V) are disabled after Wire.begin(),
 *     so SDA / SCL are pulled up to 3.3V only (KT0803L internal 47k, or external).
 *     3.3V is above ATmega328P VIH (0.6 x 5V = 3.0V), but a level shifter
 *     (e.g. PCA9306, BSS138) gives more margin.
 *
 * Wiring
 *   3.3V     -> KT0803L IOVDD, SW1, RSTB
 *   GND      -> KT0803L GND, SW2      (SW1 = H, SW2 = L : 32.768kHz crystal)
 *   A4 (SDA) -> KT0803L SDA (pull-up to 3.3V, 4.7k recommended)
 *   A5 (SCL) -> KT0803L SCL (pull-up to 3.3V, 4.7k recommended)
 *   D2       -> push button -> GND
 *
 * Button (D2)
 *   short press : next preset channel
 *   long press  : mute / unmute
 *
 * LED (D13)
 *   on         : transmitting
 *   slow blink : muted
 *   off        : standby
 *   fast blink : KT0803L not found
 *
 * Frequency and settings are saved to EEPROM.
 *
 * Deep sleep (SLEEP_AFTER_SETUP = 1)
 *   1s after KT0803L setup is done, the MCU prints a message and enters power-down sleep
 *   with interrupts disabled, i.e. it stops until reset. KT0803L keeps transmitting.
 *   Button / LED / serial commands below work only with SLEEP_AFTER_SETUP = 0.
 *   (Tip : choose the settings with SLEEP_AFTER_SETUP = 0, they are saved to EEPROM.)
 *
 * Serial command (115200bps, newline)
 *   f <MHz>     : tune (e.g. "f 88.1")
 *   c <0-5>     : select preset channel
 *   g <0-15>    : RF gain
 *   a <-15-12>  : PGA [dB]
 *   k <0-1>     : PA bias       (0:off 1:on)
 *   p <0-2>     : output level  (0:RF gain 0 1:6 2:15)
 *   i <0-2>     : input level   (0:PGA +3dB 1:0dB 2:-3dB)
 *   e <1-2>     : pre-emphasis  (1:50us 2:75us)
 *   t <0-1>     : pilot tone    (0:mono 1:stereo)
 *   b <0-3>     : bass boost    (0:off 1:5dB 2:11dB 3:17dB)
 *   m / u       : mute / unmute
 *   on / off    : power on / standby
 *   s           : status
 *   d           : register dump
 */
#include <Wire.h>
#include <EEPROM.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <KT0803L.h>

#define SLEEP_AFTER_SETUP 1  // 1 = stop MCU after setup, 0 = keep running (button / serial)

#define BTN_PIN 2
#define LED_PIN LED_BUILTIN

#define T_HOLD     1000  // [ms] long press
#define T_DEBOUNCE 30    // [ms]
#define T_RETRY    2000  // [ms] retry begin() while KT0803L not found
#define T_SLEEP    1000  // [ms] setup done -> deep sleep

#define EE_ADDR  0
#define EE_MAGIC 0x38

static KT0803L fmtx(Wire);

static const uint32_t freq[] = {87500000UL, 87800000UL, 88100000UL, 88400000UL, 88700000UL, 89000000UL};  // [Hz]
#define N_CH (sizeof(freq) / sizeof(freq[0]))

struct Settings {
    uint8_t  magic;
    uint32_t freq;      // [Hz]
    uint8_t  rfgain;    // 0..15
    int8_t   pga;       // [dB]
    uint8_t  emphasis;  // KT0803L::PRE_EMPHASIS_50_US / 75_US
    uint8_t  stereo;
    uint8_t  bass;
};

static bool txReady = false;

// ---------------------------------------------------------------- status

static void printMHz(uint32_t f)
{
    uint8_t k = (f / 10000UL) % 100;
    Serial.print(f / 1000000UL);
    Serial.print('.');
    if (k < 10) Serial.print('0');
    Serial.print(k);
    Serial.print(F("MHz"));
}

static void printStatus()
{
    static const char *const pe[]   = {"--", "50us", "75us"};
    static const char *const bass[] = {"off", "5dB", "11dB", "17dB"};

    Serial.print(F("freq="));
    printMHz(fmtx.getFrequency());
    Serial.print(F(" (actual "));
    printMHz(fmtx.getActualFrequency());
    Serial.println(')');

    Serial.print(F("power="));
    Serial.print(fmtx.isPowerOn() ? F("on") : F("off"));
    Serial.print(F("  mute="));
    Serial.print(fmtx.isMuted() ? F("on") : F("off"));
    Serial.print(F("  rfgain="));
    Serial.print(fmtx.getRfGain());
    Serial.print(F("  pa bias="));
    Serial.print(fmtx.isPaBias() ? F("on") : F("off"));
    Serial.print(F("  pga="));
    Serial.print(fmtx.getPga());
    Serial.println(F("dB"));

    Serial.print(F("emphasis="));
    Serial.print(pe[fmtx.getPreEmphasis()]);
    Serial.print(F("  "));
    Serial.print(fmtx.isPiloteTone() ? F("stereo") : F("mono"));
    Serial.print(F("  bass="));
    Serial.print(bass[fmtx.getBassBoost()]);
    Serial.print(F("  power ok="));
    Serial.println(fmtx.isPowerOk() ? F("yes") : F("no"));
}

static void updateLed()
{
    uint32_t now = millis();
    bool on;

    if (!txReady) on = (now / 100) % 2;
    else if (!fmtx.isPowerOn()) on = false;
    else if (fmtx.isMuted()) on = (now / 500) % 2;
    else on = true;
    digitalWrite(LED_PIN, on ? HIGH : LOW);
}

// ---------------------------------------------------------------- KT0803L control

static void loadSettings(Settings &s)
{
    EEPROM.get(EE_ADDR, s);
    if (s.magic != EE_MAGIC || s.freq < KT0803L::FREQ_MIN || s.freq > KT0803L::FREQ_MAX) {
        s.magic    = EE_MAGIC;
        s.freq     = freq[0];
        s.rfgain   = 0;
        s.pga      = 0;
        s.emphasis = KT0803L::PRE_EMPHASIS_50_US;  // Japan
        s.stereo   = 1;
        s.bass     = 0;
    }
}

static void saveSettings()
{
    Settings s;
    s.magic    = EE_MAGIC;
    s.freq     = fmtx.getFrequency();
    s.rfgain   = fmtx.getRfGain();
    s.pga      = fmtx.getPga();
    s.emphasis = fmtx.getPreEmphasis();
    s.stereo   = fmtx.isPiloteTone();
    s.bass     = fmtx.getBassBoost();
    EEPROM.put(EE_ADDR, s);  // put() writes changed bytes only
}

static bool startTx()
{
    Settings s;
    loadSettings(s);

    txReady = fmtx.begin(s.freq);
    if (txReady) {
        fmtx.setRfGain(s.rfgain);
        fmtx.setPga(s.pga);
        fmtx.preEmphasis(s.emphasis);
        fmtx.piloteTone(s.stereo);
        fmtx.bassBoost(s.bass);
        Serial.println(F("KT0803L ready"));
        printStatus();
    } else {
        Serial.println(F("KT0803L not found"));
    }
    return txReady;
}

static void tune(uint32_t f)
{
    if (f < KT0803L::FREQ_MIN || f > KT0803L::FREQ_MAX) {
        Serial.println(F("out of range"));
        return;
    }
    if (!fmtx.tuneTo(f)) Serial.println(F("tune failed"));
    printStatus();
}

static void nextChannel()
{
    // first preset above the current frequency
    uint32_t f = fmtx.getFrequency();
    uint8_t i = 0;
    while (i < N_CH && freq[i] <= f) i++;
    tune(freq[i < N_CH ? i : 0]);
    saveSettings();
}

static void sleepForever()
{
    Serial.println(F("setup done, MCU enters deep sleep (reset to wake up)"));
    Serial.flush();

    Wire.end();  // release SDA / SCL (bus is kept HIGH by the pull-ups)
    digitalWrite(LED_PIN, LOW);
    ADCSRA = 0;  // ADC off
    power_all_disable();

    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    cli();  // no interrupt can wake the MCU, only reset
    sleep_enable();
#ifdef sleep_bod_disable
    sleep_bod_disable();
#endif
    sleep_cpu();
    for (;;) {
    }
}

// ---------------------------------------------------------------- input

static void handleButton()
{
    static bool     state = HIGH;  // debounced
    static bool     held = false;
    static uint32_t tmChange = 0;
    static uint32_t tmPress = 0;
    uint32_t now = millis();
    bool raw = digitalRead(BTN_PIN);

    if (raw != state && now - tmChange >= T_DEBOUNCE) {
        state = raw;
        tmChange = now;
        if (state == LOW) {
            tmPress = now;
            held = false;
        } else if (!held && txReady) {
            nextChannel();
        }
    }
    if (state == LOW && !held && now - tmPress >= T_HOLD) {
        held = true;
        if (txReady) {
            fmtx.isMuted() ? fmtx.unmute() : fmtx.mute();
            printStatus();
        }
    }
}

static void handleSerial()
{
    static char buf[24];
    static uint8_t len = 0;

    while (Serial.available()) {
        char c = Serial.read();
        if (c != '\n' && c != '\r') {
            if (len < sizeof(buf) - 1) buf[len++] = c;
            continue;
        }
        if (len == 0) continue;
        buf[len] = '\0';
        len = 0;

        char *cmd = strtok(buf, " ");
        char *arg = strtok(NULL, " ");
        if (cmd == NULL) continue;
        long n = arg ? atol(arg) : -1;
        bool ok = true;

        if (!strcmp(cmd, "f") && arg) tune(static_cast<uint32_t>(lround(atof(arg) * 1000.0)) * 1000UL);
        else if (!strcmp(cmd, "c") && n >= 0 && n < (long)N_CH) tune(freq[n]);
        else if (!strcmp(cmd, "g") && arg) ok = fmtx.setRfGain(n);
        else if (!strcmp(cmd, "a") && arg) ok = fmtx.setPga(n);
        else if (!strcmp(cmd, "k") && arg) ok = fmtx.paBias(n);
        else if (!strcmp(cmd, "p") && arg) ok = fmtx.powerOutputLevel(n);
        else if (!strcmp(cmd, "i") && arg) ok = fmtx.soundInputLevel(n);
        else if (!strcmp(cmd, "e") && arg) ok = fmtx.preEmphasis(n);
        else if (!strcmp(cmd, "t") && arg) ok = fmtx.piloteTone(n);
        else if (!strcmp(cmd, "b") && arg) ok = fmtx.bassBoost(n);
        else if (!strcmp(cmd, "m")) ok = fmtx.mute();
        else if (!strcmp(cmd, "u")) ok = fmtx.unmute();
        else if (!strcmp(cmd, "on")) ok = fmtx.powerOn();
        else if (!strcmp(cmd, "off")) ok = fmtx.powerOff();
        else if (!strcmp(cmd, "s")) printStatus();
        else if (!strcmp(cmd, "d")) fmtx.serialDump(Serial);
        else Serial.println(F("? f <MHz> | c <0-5> | g <0-15> | a <dB> | k <0-1> | p/i <0-2> | e <1-2> | t <0-1> | b <0-3> | m | u | on | off | s | d"));

        if (!ok) Serial.println(F("error"));
        else if (txReady) saveSettings();
    }
}

// ---------------------------------------------------------------- main

void setup()
{
    Serial.begin(115200);
    pinMode(BTN_PIN, INPUT_PULLUP);
    pinMode(LED_PIN, OUTPUT);

    KT0803L::resetSerialInterface(SDA, SCL);
    Wire.begin();
    digitalWrite(SDA, LOW);  // disable ATmega328P internal pull-ups (5V)
    digitalWrite(SCL, LOW);
    Wire.setClock(100000);

    delay(100);  // power on delay
    startTx();
}

void loop()
{
    static uint32_t tmRetry = 0;

    if (!txReady && millis() - tmRetry >= T_RETRY) {
        tmRetry = millis();
        startTx();
    }
#if SLEEP_AFTER_SETUP
    if (txReady) {
        delay(T_SLEEP);
        sleepForever();
    }
#endif
    handleButton();
    handleSerial();
    updateLed();
}
