/*
 * KT0803L.h - Arduino library for KT Micro KT0803L FM stereo transmitter (I2C)
 *
 * API follows NS73M_I2C (SkyWodd NS73M compatible):
 *   begin(), tuneTo(), reset(), powerOn(), mute(), soundInputLevel(), ...
 * NS73M specific functions (band select, TEB lock detect, charge pump, forced subcarrier)
 * are removed, and KT0803L specific functions (RF gain, PGA, bass boost, ALC, ...) are added.
 *
 * Reference: KT0803L Monolithic Digital Stereo FM Transmitter datasheet Rev.1.3 (KT Micro, 2010)
 *   - I2C slave address : 0x3E (fixed, write 0x7C / read 0x7D), byte write / random read
 *   - Channel : CHSEL[11:0] = fTX[MHz] x 20 (50kHz step, 70 ~ 108MHz)
 *       CHSEL[11:9] = R0x01[2:0], CHSEL[8:1] = R0x00[7:0], CHSEL[0] = R0x02[7]
 *   - RF gain : RFGAIN[1:0] = R0x01[7:6], RFGAIN[2] = R0x13[7], RFGAIN[3] = R0x02[6]
 *   - PGA : PGA[2:0] = R0x01[5:3], PGA_LSB[1:0] = R0x04[5:4], PGAMOD = R0x10[0] (1 = 1dB step)
 *   - Only the defined registers may be read / written (datasheet 4, note 1)
 *
 * MIT License
 */
#pragma once

#include <Arduino.h>
#include <Wire.h>

class KT0803L {
public:
    static constexpr uint8_t I2C_ADDR = 0x3E;

    static constexpr uint32_t FREQ_MIN  = 70000000UL;   // [Hz]
    static constexpr uint32_t FREQ_MAX  = 108000000UL;  // [Hz]
    static constexpr uint32_t FREQ_STEP = 50000UL;      // [Hz]

    static constexpr int8_t PGA_MIN = -15;  // [dB]
    static constexpr int8_t PGA_MAX = 12;   // [dB]

    // PHTCNST (KT0803L has no pre-emphasis off)
    typedef enum {
        NO_PRE_EMPHASIS,     // not supported
        PRE_EMPHASIS_50_US,  // Japan / Europe
        PRE_EMPHASIS_75_US,  // USA
    } Pre_emphasis_t;

    // PGA : audio input level for full modulation
    typedef enum {
        INPUT_LEVEL_LOW,     // PGA +3dB
        INPUT_LEVEL_MEDIUM,  // PGA  0dB
        INPUT_LEVEL_HIGH,    // PGA -3dB
    } Input_level_t;

    typedef enum {
        DISABLE,
        ENABLE,
    } Mode_t;

    // RFGAIN : TX power level (datasheet table 4)
    typedef enum {
        OUTPUT_LEVEL_LOW,     // RFGAIN  0 :  95.5dBuV
        OUTPUT_LEVEL_MEDIUM,  // RFGAIN  6 : 101.5dBuV
        OUTPUT_LEVEL_HIGH,    // RFGAIN 15 : 108.0dBuV (112.5dBuV with PA_BIAS)
    } Output_level_t;

    explicit KT0803L(TwoWire &wire = Wire, uint8_t address = I2C_ADDR);

    // ---- NS73M_I2C compatible API ----
    // Wire.begin() must be called beforehand.
    bool begin(uint32_t frequency);
    bool tuneTo(uint32_t frequency);  // [Hz]
    bool powerOn();
    bool powerOff();  // software standby
    bool mute();
    bool unmute();
    bool soundInputLevel(uint8_t input_level);
    bool powerOutputLevel(uint8_t power_level);
    bool preEmphasis(uint8_t pre_emphasis);
    bool piloteTone(uint8_t mode);  // ENABLE = stereo, DISABLE = mono
    bool reset();     // write all shadow registers to the chip again (no software reset in KT0803L)
    void allReset();  // reset shadow registers to datasheet default values (no I2C access)
    void serialDump(Print &out = Serial);

    // ---- Extended API ----
    bool isConnected();
    static void resetSerialInterface(int sdaPin, int sclPin);  // I2C bus recovery, call BEFORE Wire.begin()

    uint32_t getFrequency() const { return _frequency; }  // [Hz] requested
    uint32_t getActualFrequency() const;                  // [Hz] 50kHz step
    static uint16_t frequencyToChannel(uint32_t frequency);

    bool    setRfGain(uint8_t rfgain);  // 0..15
    uint8_t getRfGain() const;
    bool    paBias(uint8_t mode);       // PA bias current enhancement (RFGAIN >= 8)
    bool    setPga(int8_t db);          // -15..+12dB, 1dB step
    int8_t  getPga() const;
    bool    bassBoost(uint8_t level);   // 0:off 1:5dB 2:11dB 3:17dB
    uint8_t getBassBoost() const { return _reg[0x04] & 0x03; }
    bool    alc(uint8_t mode);
    bool    pilotAmplitude(uint8_t mode);  // DISABLE = low, ENABLE = high
    bool    silenceDetect(uint8_t mode);   // SLNCDIS
    bool    autoPaDown(uint8_t mode);      // AUTO_PADN : PA power down while silence is detected

    bool isPowerOk();  // R0x0F PW_OK
    bool isSilence();  // R0x0F SLNCID (silence detected)

    bool isPowerOn() const { return !(_reg[0x0B] & 0x80); }
    bool isMuted() const { return _reg[0x02] & 0x08; }
    bool isPiloteTone() const { return !(_reg[0x04] & 0x40); }
    bool isAlc() const { return _reg[0x04] & 0x80; }
    bool isPaBias() const { return _reg[0x0E] & 0x02; }
    uint8_t getInputLevel() const;
    uint8_t getOutputLevel() const;
    uint8_t getPreEmphasis() const { return (_reg[0x02] & 0x01) ? PRE_EMPHASIS_50_US : PRE_EMPHASIS_75_US; }

    bool    writeRegister(uint8_t reg, uint8_t value);
    bool    readRegister(uint8_t reg, uint8_t &value);
    uint8_t getShadowRegister(uint8_t reg) const { return reg < N_REG ? _reg[reg] : 0; }

private:
    static constexpr uint8_t N_REG = 0x28;

    bool updateBits(uint8_t reg, uint8_t mask, uint8_t value);
    void setChannelBits(uint16_t ch);

    TwoWire &_wire;
    uint8_t  _addr;
    uint8_t  _reg[N_REG] = {};
    uint32_t _frequency  = 86000000UL;
};
