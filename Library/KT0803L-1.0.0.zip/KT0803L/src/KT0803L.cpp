/*
 * KT0803L.cpp - Arduino library for KT Micro KT0803L FM stereo transmitter (I2C)
 *
 * MIT License
 */
#include "KT0803L.h"

namespace {
// R0x00 : CHSEL[8:1]
// R0x01 : RFGAIN[1:0], PGA[2:0], CHSEL[11:9]
constexpr uint8_t R01_RFGAIN = 0xC0;
constexpr uint8_t R01_PGA    = 0x38;
constexpr uint8_t R01_CHSEL  = 0x07;
// R0x02 : CHSEL[0], RFGAIN[3], -, -, MUTE, PLTADJ, -, PHTCNST
constexpr uint8_t R02_CHSEL   = 0x80;
constexpr uint8_t R02_RFGAIN3 = 0x40;
constexpr uint8_t R02_MUTE    = 0x08;  // 1 = mute
constexpr uint8_t R02_PLTADJ  = 0x04;  // 1 = pilot amplitude high
constexpr uint8_t R02_PHTCNST = 0x01;  // 1 = 50us, 0 = 75us
// R0x04 : ALC_EN, MONO, PGA_LSB[1:0], -, -, BASS[1:0]
constexpr uint8_t R04_ALC     = 0x80;
constexpr uint8_t R04_MONO    = 0x40;  // 1 = mono
constexpr uint8_t R04_PGA_LSB = 0x30;
constexpr uint8_t R04_BASS    = 0x03;
// R0x0B : Standby, -, PDPA, -, -, AUTO_PADN, -, -
constexpr uint8_t R0B_STANDBY   = 0x80;  // 1 = standby
constexpr uint8_t R0B_AUTO_PADN = 0x04;  // 1 = PA power down while silence
// R0x0E : PA_BIAS
constexpr uint8_t R0E_PA_BIAS = 0x02;
// R0x0F (read only) : PW_OK, SLNCID
constexpr uint8_t R0F_PW_OK  = 0x10;
constexpr uint8_t R0F_SLNCID = 0x04;
// R0x10 : PGAMOD
constexpr uint8_t R10_PGAMOD = 0x01;  // 1 = 1dB step with PGA_LSB
// R0x12 : SLNCDIS, SLNCTHL[2:0], SLNCTHH[2:0], SW_MOD
constexpr uint8_t R12_SLNCDIS = 0x80;  // 1 = silence detection disabled
// R0x13 : RFGAIN[2], -, -, -, -, PA_CTRL, -, -
constexpr uint8_t R13_RFGAIN2 = 0x80;

// Datasheet default values of the defined registers (R0x0F is read only)
struct RegDefault {
    uint8_t reg;
    uint8_t value;
};
constexpr RegDefault REG_DEFAULTS[] = {
    {0x00, 0x5C}, {0x01, 0xC3}, {0x02, 0x40}, {0x04, 0x04}, {0x0B, 0x00}, {0x0C, 0x00},
    {0x0E, 0x02}, {0x0F, 0x00}, {0x10, 0xA8}, {0x12, 0x80}, {0x13, 0x80}, {0x14, 0x00},
    {0x15, 0xE0}, {0x16, 0x00}, {0x17, 0x00}, {0x1E, 0x00}, {0x26, 0xA0}, {0x27, 0x00},
};
constexpr uint32_t DEFAULT_FREQUENCY = 86000000UL;  // CHSEL = 1720

// Registers written by this library (write order of reset())
constexpr uint8_t MANAGED_REGS[] = {0x13, 0x0E, 0x10, 0x12, 0x04, 0x02, 0x01, 0x00, 0x0B};

constexpr uint8_t RFGAIN_OF_LEVEL[] = {0, 6, 15};  // OUTPUT_LEVEL_LOW / MEDIUM / HIGH
constexpr int8_t  PGA_OF_LEVEL[]    = {3, 0, -3};  // INPUT_LEVEL_LOW / MEDIUM / HIGH [dB]

constexpr uint16_t T_POWER_OK = 200;  // [ms] max wait for PW_OK in begin()
}  // namespace

KT0803L::KT0803L(TwoWire &wire, uint8_t address) : _wire(wire), _addr(address) {
    allReset();
}

// ================================================================ NS73M_I2C compatible API

bool KT0803L::begin(uint32_t frequency) {
    if (frequency < FREQ_MIN || frequency > FREQ_MAX) return false;

    allReset();
    delay(5);  // power on rise time
    if (!isConnected()) return false;
    for (uint16_t t = 0; t < T_POWER_OK && !isPowerOk(); t += 10) delay(10);

    // Load current register values so that reserved bits are kept
    for (const RegDefault &d : REG_DEFAULTS) {
        if (!readRegister(d.reg, _reg[d.reg])) return false;
    }

    // Initial set : stereo, 50us, unmute, PGA 0dB (1dB step mode), RF gain 0, bass off
    _frequency = frequency;
    setChannelBits(frequencyToChannel(frequency));
    _reg[0x02] = (_reg[0x02] & ~(R02_MUTE | R02_PHTCNST)) | R02_PHTCNST;
    _reg[0x04] &= ~(R04_MONO | R04_PGA_LSB | R04_BASS);
    _reg[0x01] &= ~R01_PGA;
    _reg[0x10] |= R10_PGAMOD;
    _reg[0x0B] &= ~R0B_STANDBY;
    if (!reset()) return false;
    return setRfGain(RFGAIN_OF_LEVEL[OUTPUT_LEVEL_LOW]);
}

bool KT0803L::tuneTo(uint32_t frequency) {
    if (frequency < FREQ_MIN || frequency > FREQ_MAX) return false;
    _frequency = frequency;

    uint16_t ch = frequencyToChannel(frequency);
    if (!updateBits(0x02, R02_CHSEL, (ch & 0x01) ? R02_CHSEL : 0)) return false;
    if (!updateBits(0x01, R01_CHSEL, ch >> 9)) return false;
    return updateBits(0x00, 0xFF, ch >> 1);
}

bool KT0803L::powerOn() {
    return updateBits(0x0B, R0B_STANDBY, 0);
}

bool KT0803L::powerOff() {
    return updateBits(0x0B, R0B_STANDBY, R0B_STANDBY);
}

bool KT0803L::mute() {
    return updateBits(0x02, R02_MUTE, R02_MUTE);
}

bool KT0803L::unmute() {
    return updateBits(0x02, R02_MUTE, 0);
}

bool KT0803L::soundInputLevel(uint8_t input_level) {
    if (input_level > INPUT_LEVEL_HIGH) return false;
    return setPga(PGA_OF_LEVEL[input_level]);
}

bool KT0803L::powerOutputLevel(uint8_t power_level) {
    if (power_level > OUTPUT_LEVEL_HIGH) return false;
    return setRfGain(RFGAIN_OF_LEVEL[power_level]);
}

bool KT0803L::preEmphasis(uint8_t pre_emphasis) {
    switch (pre_emphasis) {
        case PRE_EMPHASIS_50_US: return updateBits(0x02, R02_PHTCNST, R02_PHTCNST);
        case PRE_EMPHASIS_75_US: return updateBits(0x02, R02_PHTCNST, 0);
    }
    return false;  // NO_PRE_EMPHASIS is not supported
}

bool KT0803L::piloteTone(uint8_t mode) {
    return updateBits(0x04, R04_MONO, mode ? 0 : R04_MONO);
}

bool KT0803L::reset() {
    for (uint8_t r : MANAGED_REGS) {
        if (!writeRegister(r, _reg[r])) return false;
    }
    return true;
}

void KT0803L::allReset() {
    memset(_reg, 0, sizeof(_reg));
    for (const RegDefault &d : REG_DEFAULTS) _reg[d.reg] = d.value;
    _frequency = DEFAULT_FREQUENCY;
}

void KT0803L::serialDump(Print &out) {
    out.println(F("Reg   shadow  chip"));
    for (const RegDefault &d : REG_DEFAULTS) {
        uint8_t v;
        char buf[24];
        if (readRegister(d.reg, v)) snprintf(buf, sizeof(buf), "0x%02X  0x%02X    0x%02X", d.reg, _reg[d.reg], v);
        else snprintf(buf, sizeof(buf), "0x%02X  0x%02X    --", d.reg, _reg[d.reg]);
        out.println(buf);
    }
}

// ================================================================ Extended API

bool KT0803L::isConnected() {
    _wire.beginTransmission(_addr);
    return _wire.endTransmission() == 0;
}

void KT0803L::resetSerialInterface(int sdaPin, int sclPin) {
    // I2C bus recovery : 9 clocks with SDA released, then STOP
    // Open-drain emulation : release = HIGH by pull-up, drive = LOW
    // MCU internal pull-ups are not used (they pull up to 5V on 5V boards).
    // KT0803L has 47k pull-ups to IOVDD on SDA / SCL.
    auto release = [](int pin) { pinMode(pin, INPUT); };
    auto drive   = [](int pin) { digitalWrite(pin, LOW); pinMode(pin, OUTPUT); };
    constexpr uint8_t T = 5;  // [us]

    release(sdaPin);
    release(sclPin);
    delayMicroseconds(T);
    for (uint8_t i = 0; i < 9; i++) {
        drive(sclPin);
        delayMicroseconds(T);
        release(sclPin);
        delayMicroseconds(T);
    }
    drive(sclPin);  // STOP
    drive(sdaPin);
    delayMicroseconds(T);
    release(sclPin);
    delayMicroseconds(T);
    release(sdaPin);
    delayMicroseconds(T);
}

uint16_t KT0803L::frequencyToChannel(uint32_t frequency) {
    // CHSEL = round(fTX / 50kHz)
    return static_cast<uint16_t>((frequency + FREQ_STEP / 2) / FREQ_STEP);
}

uint32_t KT0803L::getActualFrequency() const {
    uint16_t ch = ((_reg[0x01] & R01_CHSEL) << 9) | (_reg[0x00] << 1) | ((_reg[0x02] & R02_CHSEL) ? 1 : 0);
    return static_cast<uint32_t>(ch) * FREQ_STEP;
}

bool KT0803L::setRfGain(uint8_t rfgain) {
    if (rfgain > 15) return false;
    if (!updateBits(0x01, R01_RFGAIN, (rfgain & 0x03) << 6)) return false;
    if (!updateBits(0x13, R13_RFGAIN2, (rfgain & 0x04) ? R13_RFGAIN2 : 0)) return false;
    return updateBits(0x02, R02_RFGAIN3, (rfgain & 0x08) ? R02_RFGAIN3 : 0);
}

uint8_t KT0803L::getRfGain() const {
    return ((_reg[0x01] & R01_RFGAIN) >> 6) | ((_reg[0x13] & R13_RFGAIN2) ? 0x04 : 0) |
           ((_reg[0x02] & R02_RFGAIN3) ? 0x08 : 0);
}

bool KT0803L::paBias(uint8_t mode) {
    return updateBits(0x0E, R0E_PA_BIAS, mode ? R0E_PA_BIAS : 0);
}

bool KT0803L::setPga(int8_t db) {
    // 1dB step mode (PGAMOD = 1), datasheet R0x04 table
    //   +1..+12dB : PGA = 101..111, PGA_LSB = (db - 1) % 4
    //   0..-15dB  : PGA = 000..011, PGA_LSB = -db % 4
    if (db < PGA_MIN || db > PGA_MAX) return false;
    uint8_t pga, lsb;
    if (db > 0) {
        pga = 0x05 + (db - 1) / 4;
        lsb = (db - 1) % 4;
    } else {
        pga = -db / 4;
        lsb = -db % 4;
    }
    if (!(_reg[0x10] & R10_PGAMOD) && !updateBits(0x10, R10_PGAMOD, R10_PGAMOD)) return false;
    if (!updateBits(0x04, R04_PGA_LSB, lsb << 4)) return false;
    return updateBits(0x01, R01_PGA, pga << 3);
}

int8_t KT0803L::getPga() const {
    uint8_t pga = (_reg[0x01] & R01_PGA) >> 3;
    if (!(_reg[0x10] & R10_PGAMOD)) {  // 4dB step mode
        int8_t db = (pga & 0x03) * 4;
        return (pga & 0x04) ? db : -db;
    }
    uint8_t lsb = (_reg[0x04] & R04_PGA_LSB) >> 4;
    if (pga == 0x04) return 0;
    if (pga & 0x04) return (pga - 0x05) * 4 + lsb + 1;
    return -static_cast<int8_t>(pga * 4 + lsb);
}

bool KT0803L::bassBoost(uint8_t level) {
    if (level > 3) return false;
    return updateBits(0x04, R04_BASS, level);
}

bool KT0803L::alc(uint8_t mode) {
    return updateBits(0x04, R04_ALC, mode ? R04_ALC : 0);
}

bool KT0803L::pilotAmplitude(uint8_t mode) {
    return updateBits(0x02, R02_PLTADJ, mode ? R02_PLTADJ : 0);
}

bool KT0803L::silenceDetect(uint8_t mode) {
    return updateBits(0x12, R12_SLNCDIS, mode ? 0 : R12_SLNCDIS);
}

bool KT0803L::autoPaDown(uint8_t mode) {
    return updateBits(0x0B, R0B_AUTO_PADN, mode ? R0B_AUTO_PADN : 0);
}

bool KT0803L::isPowerOk() {
    uint8_t v;
    return readRegister(0x0F, v) && (v & R0F_PW_OK);
}

bool KT0803L::isSilence() {
    uint8_t v;
    return readRegister(0x0F, v) && (v & R0F_SLNCID);
}

uint8_t KT0803L::getInputLevel() const {
    int8_t db = getPga();
    if (db > 0) return INPUT_LEVEL_LOW;
    return db < 0 ? INPUT_LEVEL_HIGH : INPUT_LEVEL_MEDIUM;
}

uint8_t KT0803L::getOutputLevel() const {
    uint8_t g = getRfGain();
    if (g < 3) return OUTPUT_LEVEL_LOW;
    return g < 11 ? OUTPUT_LEVEL_MEDIUM : OUTPUT_LEVEL_HIGH;
}

bool KT0803L::writeRegister(uint8_t reg, uint8_t value) {
    _wire.beginTransmission(_addr);
    _wire.write(reg);
    _wire.write(value);
    return _wire.endTransmission() == 0;
}

bool KT0803L::readRegister(uint8_t reg, uint8_t &value) {
    // Random read : register address, repeated START, data
    _wire.beginTransmission(_addr);
    _wire.write(reg);
    if (_wire.endTransmission(false) != 0) return false;
    if (_wire.requestFrom(_addr, static_cast<uint8_t>(1)) != 1) return false;
    value = _wire.read();
    return true;
}

bool KT0803L::updateBits(uint8_t reg, uint8_t mask, uint8_t value) {
    if (reg >= N_REG) return false;
    uint8_t v = (_reg[reg] & ~mask) | (value & mask);
    if (!writeRegister(reg, v)) return false;
    _reg[reg] = v;
    return true;
}

void KT0803L::setChannelBits(uint16_t ch) {
    _reg[0x00] = (ch >> 1) & 0xFF;
    _reg[0x01] = (_reg[0x01] & ~R01_CHSEL) | ((ch >> 9) & R01_CHSEL);
    _reg[0x02] = (_reg[0x02] & ~R02_CHSEL) | ((ch & 0x01) ? R02_CHSEL : 0);
}
