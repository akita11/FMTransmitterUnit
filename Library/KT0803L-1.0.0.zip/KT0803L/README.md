# KT0803L

KT Micro **KT0803L** FM ステレオトランスミッタを I2C で制御する Arduino ライブラリです。

NS73M_I2C ライブラリ（新潟精密 NS73M 用）と同じ API（`begin()` / `tuneTo()` / `mute()` …）で使えるようにし、KT0803L 固有の機能（RF ゲイン、PGA、低音ブースト、ALC など）を追加しています。

## 特長

- NS73M_I2C と同じ関数名・列挙子（移行が簡単）
- 任意の `TwoWire` インスタンスを使用可能（`Wire` / `Wire1` など）
- 周波数からチャンネル番号 CHSEL を自動計算（50kHz ステップ、70〜108MHz）
- PGA を 1dB ステップ（-15〜+12dB）で設定
- `begin()` でチップのレジスタを読み込み、予約ビットの値を保持したまま設定
- データシートで定義されたレジスタだけを読み書き（データシート 4 章 Note 1）
- シャドウレジスタによる現在設定の取得（`isMuted()`、`getRfGain()` など）
- 全レジスタのダンプ（シャドウ値とチップから読んだ値の比較）

## 対応環境

- Arduino フレームワーク（`Wire.h` が使える環境）
- ビルド確認：Arduino UNO R3（ATmega328P）、M5Stack Core2（ESP32）／PlatformIO

## 接続

| KT0803L 端子 | 接続先 | 備考 |
|---|---|---|
| SDA（13） | SDA | 内部に 47kΩ プルアップあり |
| SCL（14） | SCL | 内部に 47kΩ プルアップあり。最大 400kHz |
| SW1（8）/ SW2（9） | VDD / GND | チップ有効化とクロック選択（下表） |
| RSTB（10） | VDD | L でリセット（全レジスタが初期値に戻る） |
| IOVDD（4） | 1.6〜3.6V | |

| SW1 | SW2 | 動作 | クロック |
|---|---|---|---|
| 0 | 0 | 電源オフ | − |
| 0 | 1 | 動作 | 12MHz |
| 1 | 0 | 動作 | 32.768kHz |
| 1 | 1 | 動作 | 7.6MHz |

I2C アドレスは `0x3E` 固定です（`KT0803L::I2C_ADDR`、書き込み 0x7C / 読み出し 0x7D）。クロックは SW1/SW2 で選ぶ前提で、ライブラリはクロック関係のレジスタ（R0x17 の XTAL_SEL、R0x1E）を変更しません。

> 外付けインダクタで PA に給電する高出力構成（データシート Figure 11）では、PW_OK が 1 になった直後に R0x13 の PA_CTRL を 1 にしないとデバイスが壊れることがあります。このライブラリは PA_CTRL を変更しないので、その構成で使う場合は `writeRegister()` で設定してください。

## インストール

Arduino IDE と PlatformIO へのインストール方法は [usage.md](usage.md) を見てください。

## 使い方

```cpp
#include <Wire.h>
#include <KT0803L.h>

KT0803L fmtx(Wire);

void setup() {
    Serial.begin(115200);
    Wire.begin();
    Wire.setClock(100000);

    if (!fmtx.begin(88100000UL)) {  // 88.1MHz で送信開始
        Serial.println("KT0803L not found");
        return;
    }
    fmtx.setRfGain(0);                                // 送信出力 最小
    fmtx.setPga(0);                                   // 入力ゲイン 0dB（-15〜+12dB）
    fmtx.preEmphasis(KT0803L::PRE_EMPHASIS_50_US);    // 日本・欧州
}

void loop() {
}
```

## スケッチ例

| スケッチ | 対象 | 内容 |
|---|---|---|
| [examples/KT0803L_FM_Transmitter](examples/KT0803L_FM_Transmitter/KT0803L_FM_Transmitter.ino) | Arduino UNO R3 | 設定完了の 1 秒後にマイコンをディープスリープ（Power-down）で止め、KT0803L だけが送信を続ける。`SLEEP_AFTER_SETUP` を 0 にすると、ボタン（D2）でのプリセット選局（短押し）・ミュート（長押し）、LED（D13）での状態表示、シリアルコマンドが使える。周波数と設定は EEPROM に保存 |

Arduino IDE では「ファイル → スケッチ例 → KT0803L」から開けます。PlatformIO でのビルド方法は [usage.md](usage.md) にあります。

### Arduino UNO R3（5V ボード）との接続

KT0803L は 3.3V 系のデバイス（IOVDD 1.6〜3.6V）です。

| UNO R3 | KT0803L |
|---|---|
| 3.3V | IOVDD、SW1、RSTB |
| GND | GND、SW2（SW1 = H、SW2 = L で 32.768kHz 水晶） |
| A4（SDA） | SDA（3.3V へプルアップ。4.7kΩ 推奨） |
| A5（SCL） | SCL（3.3V へプルアップ。4.7kΩ 推奨） |
| D2 | プッシュボタン → GND |

- `Wire.begin()` は ATmega328P の内蔵プルアップ（5V）を有効にするので、スケッチ例では直後に `digitalWrite(SDA, LOW)` / `digitalWrite(SCL, LOW)` で無効にしています。
- プルアップを 3.3V にした場合の H レベル（3.3V）は、ATmega328P の VIH（0.6 × 5V = 3.0V）をかろうじて超える程度です。余裕を持たせたいときは、レベル変換（PCA9306、BSS138 など）を入れてください。
- `resetSerialInterface()` はマイコンの内蔵プルアップを使いません（KT0803L 内蔵の 47kΩ か外付けのプルアップで H にします）。

## API

### 基本（NS73M_I2C 互換）

| 関数 | 説明 |
|---|---|
| `KT0803L(TwoWire &wire = Wire, uint8_t address = 0x3E)` | コンストラクタ |
| `bool begin(uint32_t frequency)` | 初期化して指定周波数 [Hz] で送信開始。`Wire.begin()` は事前に呼ぶこと |
| `bool tuneTo(uint32_t frequency)` | 周波数 [Hz] を変更 |
| `bool powerOn()` / `bool powerOff()` | 送信開始／スタンバイ |
| `bool mute()` / `bool unmute()` | ミュート／解除 |
| `bool soundInputLevel(uint8_t)` | `INPUT_LEVEL_LOW`（PGA +3dB）/ `MEDIUM`（0dB）/ `HIGH`（-3dB） |
| `bool powerOutputLevel(uint8_t)` | `OUTPUT_LEVEL_LOW`（RFGAIN 0）/ `MEDIUM`（6）/ `HIGH`（15） |
| `bool preEmphasis(uint8_t)` | `PRE_EMPHASIS_50_US` / `PRE_EMPHASIS_75_US`。`NO_PRE_EMPHASIS` は非対応で `false` |
| `bool piloteTone(uint8_t mode)` | `ENABLE` = ステレオ / `DISABLE` = モノラル |
| `bool reset()` | シャドウレジスタの値をチップに書き直す（KT0803L にはソフトウェアリセットがないため） |
| `void allReset()` | シャドウレジスタをデータシートの初期値に戻す（I2C アクセスなし） |
| `void serialDump(Print &out = Serial)` | 定義済みの全レジスタについて、シャドウ値とチップの値を表示 |

`bool` を返す関数は I2C 通信に成功すると `true` を返します。

`begin()` は、PW_OK（R0x0F[4]）が 1 になるのを最大 200ms 待ってからレジスタを読み込み、次の状態にします。

- ステレオ、プリエンファシス 50µs、ミュート解除、低音ブースト off
- PGA 0dB（1dB ステップモード：PGAMOD = 1）
- RF ゲイン 0（最小、95.5dBµV）

それ以外（PA_BIAS、ALC、無音検出など）はチップの値のままです。

> プリエンファシスについて、データシートの表記は「75µs：USA, Japan」ですが、日本の FM 放送の規格は 50µs です。日本で使うときは `PRE_EMPHASIS_50_US` を選んでください。

### 拡張

| 関数 | 説明 |
|---|---|
| `bool isConnected()` | I2C で応答があるか |
| `static void resetSerialInterface(int sda, int scl)` | I2C バスのリカバリ（9 クロック → STOP）。`Wire.begin()` より前に呼ぶ。マイコンの内蔵プルアップは使わない |
| `uint32_t getFrequency()` | 設定した周波数 [Hz] |
| `uint32_t getActualFrequency()` | 実際の送信周波数 [Hz]（50kHz ステップに丸めた値） |
| `static uint16_t frequencyToChannel(uint32_t)` | 周波数からチャンネル番号 CHSEL を計算 |
| `bool setRfGain(uint8_t)` / `uint8_t getRfGain()` | RF ゲイン 0〜15（下表） |
| `bool paBias(uint8_t mode)` / `bool isPaBias()` | PA バイアス電流の増強（R0x0E[1]、初期値は有効）。RF ゲイン 8 以上で出力が増える |
| `bool setPga(int8_t db)` / `int8_t getPga()` | 音声入力ゲイン -15〜+12dB（1dB 刻み、`PGA_MIN` / `PGA_MAX`） |
| `bool bassBoost(uint8_t)` / `uint8_t getBassBoost()` | 低音ブースト 0:off 1:5dB 2:11dB 3:17dB |
| `bool alc(uint8_t mode)` / `bool isAlc()` | ALC（自動レベル制御）の有効／無効 |
| `bool pilotAmplitude(uint8_t mode)` | パイロットトーンの振幅 `DISABLE` = 低 / `ENABLE` = 高 |
| `bool silenceDetect(uint8_t mode)` | 無音検出の有効／無効（R0x12 の SLNCDIS。初期値は無効） |
| `bool autoPaDown(uint8_t mode)` | 無音を検出している間、PA を自動で止める（R0x0B の AUTO_PADN） |
| `bool isPowerOk()` | 電源状態 PW_OK（R0x0F[4]）を読む |
| `bool isSilence()` | 無音検出 SLNCID（R0x0F[2]）を読む。`silenceDetect(ENABLE)` のときだけ有効 |
| `isPowerOn()` / `isMuted()` / `isPiloteTone()` | 現在の状態 |
| `getInputLevel()` / `getOutputLevel()` / `getPreEmphasis()` | 現在の設定値（列挙子の値） |
| `bool writeRegister(uint8_t reg, uint8_t value)` | レジスタへ直接書き込み（シャドウレジスタは更新しない） |
| `bool readRegister(uint8_t reg, uint8_t &value)` | レジスタ読み出し |
| `uint8_t getShadowRegister(uint8_t reg)` | シャドウレジスタの値 |

### RF ゲイン（データシート Table 4）

| RFGAIN | 出力 [dBµV] | RFGAIN | 出力 [dBµV] | PA_BIAS = 1 [dBµV] |
|---|---|---|---|---|
| 0 | 95.5 | 8 | 105.1 | 107.2 |
| 1 | 96.5 | 9 | 105.6 | 108.0 |
| 2 | 97.5 | 10 | 106.2 | 108.7 |
| 3 | 98.2 | 11 | 106.5 | 109.5 |
| 4 | 98.9 | 12 | 107.0 | 110.3 |
| 5 | 100.0 | 13 | 107.4 | 111.0 |
| 6 | 101.5 | 14 | 107.7 | 111.7 |
| 7 | 102.8 | 15 | 108.0 | 112.5 |

チップの初期値は RFGAIN = 15、PA_BIAS = 1（最大出力）です。

### NS73M_I2C との対応

| NS73M_I2C | KT0803L |
|---|---|
| `begin(frequency, tebPin)` | `begin(frequency)`（TEB 端子なし） |
| `tuneTo(frequency, doReset)` | `tuneTo(frequency)` |
| `reset()`（ソフトウェアリセット） | `reset()`（シャドウレジスタを書き直す） |
| `frequencyToN()` | `frequencyToChannel()` |
| `I2C_ADDR_LA_LOW` / `I2C_ADDR_LA_HIGH` | `I2C_ADDR`（0x3E 固定） |
| `forcedSubCarrier()` / `chargePumps()` / `unlockDetect()` | なし（KT0803L に該当機能なし） |
| `selectBand()` などのバンド関係 / `isLocked()` などのロック検出 | なし（PLL はチップ内で自動制御） |

## 動作の詳細

### 周波数の設定

チャンネル番号は次式で計算し、3 つのレジスタに分けて書き込みます。

```
CHSEL[11:0] = fTX / 50kHz
CHSEL[11:9] -> R0x01[2:0]
CHSEL[8:1]  -> R0x00[7:0]
CHSEL[0]    -> R0x02[7]
```

範囲は `FREQ_MIN`（70MHz）〜 `FREQ_MAX`（108MHz）です。チップの初期周波数は 86MHz です。チャンネルを変えている間はミュートされます（R0x12 の SW_MOD = 0、初期値）。

### RF ゲイン

RFGAIN[3:0] は R0x01[7:6]（bit1:0）、R0x13[7]（bit2）、R0x02[6]（bit3）に分かれています。

### PGA

PGAMOD（R0x10[0]）を 1 にして、PGA[2:0]（R0x01[5:3]）と PGA_LSB[1:0]（R0x04[5:4]）で 1dB 刻みに設定します。

| ゲイン | PGA[2:0] | PGA_LSB[1:0] |
|---|---|---|
| +1〜+12dB | 101〜111 | (dB - 1) mod 4 |
| 0dB | 000 | 00 |
| -1〜-15dB | 000〜011 | -dB mod 4 |

## 注意

日本国内で免許なしに FM 送信できるのは、電波法の「著しく微弱な電波」（322MHz 以下では 3m の距離で電界強度 500µV/m 以下）の範囲に限られます。KT0803L は最大出力が大きいので、RF ゲイン・アンテナ・周波数を選ぶときは法令の範囲に収まるよう注意してください。

## 参考資料

- KT0803L Monolithic Digital Stereo FM Transmitter datasheet Rev.1.3（KT Micro, 2010）

## ライセンス

MIT License
